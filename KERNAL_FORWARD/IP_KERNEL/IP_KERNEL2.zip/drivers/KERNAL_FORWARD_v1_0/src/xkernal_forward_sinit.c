// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xkernal_forward.h"

extern XKernal_forward_Config XKernal_forward_ConfigTable[];

XKernal_forward_Config *XKernal_forward_LookupConfig(u16 DeviceId) {
	XKernal_forward_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XKERNAL_FORWARD_NUM_INSTANCES; Index++) {
		if (XKernal_forward_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XKernal_forward_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XKernal_forward_Initialize(XKernal_forward *InstancePtr, u16 DeviceId) {
	XKernal_forward_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XKernal_forward_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XKernal_forward_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

